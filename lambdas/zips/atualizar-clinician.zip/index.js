import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, UpdateCommand, GetCommand } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({ region: "sa-east-1" });
const dynamo = DynamoDBDocumentClient.from(client);
const TABLE_NAME = "PsicoCare";

export const handler = async (event) => {
  try {
    const clinicianId = event.pathParameters?.clinicianId;
    const body = JSON.parse(event.body);
    const { name, phone, councilId, profession, birthDate, especialidade, clinica, enderecoClinica } = body;

    if (!clinicianId) {
      return response(400, { error: "clinicianId é obrigatório" });
    }

    // Verifica se o psicólogo existe
    const existing = await dynamo.send(new GetCommand({
      TableName: TABLE_NAME,
      Key: {
        PK: `CLINICIAN#${clinicianId}`,
        SK: "PROFILE"
      }
    }));

    if (!existing.Item) {
      return response(404, { error: "Psicólogo não encontrado" });
    }

    // Monta os campos a atualizar
    const updatedData = {
      ...existing.Item.data,
      ...(name && { name }),
      ...(phone && { phone }),
      ...(councilId && { councilId }),
      ...(profession && { profession }),
      ...(birthDate && { birthDate }),
      ...(especialidade && { especialidade }),
      ...(clinica && { clinica }),
      ...(enderecoClinica && { enderecoClinica }),
      updatedAt: new Date().toISOString(),
    };

    await dynamo.send(new UpdateCommand({
      TableName: TABLE_NAME,
      Key: {
        PK: `CLINICIAN#${clinicianId}`,
        SK: "PROFILE"
      },
      UpdateExpression: "SET #data = :data",
      ExpressionAttributeNames: {
        "#data": "data"
      },
      ExpressionAttributeValues: {
        ":data": updatedData
      }
    }));

    return response(200, {
      id: clinicianId,
      ...updatedData
    });

  } catch (err) {
    console.error(err);
    return response(500, { error: "Erro interno do servidor" });
  }
};

const response = (statusCode, body) => ({
  statusCode,
  headers: {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*"
  },
  body: JSON.stringify(body)
});