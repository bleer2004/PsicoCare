import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand, UpdateCommand } from "@aws-sdk/lib-dynamodb";
import bcrypt from "bcryptjs";

const client = new DynamoDBClient({ region: "sa-east-1" });
const dynamo = DynamoDBDocumentClient.from(client);
const TABLE_NAME = "PsicoCare";

export const handler = async (event) => {
  try {
    const body = JSON.parse(event.body);
    const { clinicianId, currentPassword, newPassword } = body;

    // 1. Validação básica
    if (!clinicianId || !currentPassword || !newPassword) {
      return response(400, { error: "Todos os campos são obrigatórios." });
    }

    if (newPassword.length < 6) {
      return response(400, { error: "A nova senha deve ter pelo menos 6 caracteres." });
    }

    // 2. Busca o profissional no banco para pegar o hash da senha atual
    const userResult = await dynamo.send(new GetCommand({
      TableName: TABLE_NAME,
      Key: {
        PK: `CLINICIAN#${clinicianId}`,
        SK: "PROFILE"
      }
    }));

    if (!userResult.Item) {
      return response(404, { error: "Profissional não encontrado." });
    }

    const clinician = userResult.Item;

    // 3. Verifica se a senha atual está correta (compara com o hash do banco)
    // O banco costuma salvar dentro de data.passwordHash
    const passwordMatch = await bcrypt.compare(currentPassword, clinician.data.passwordHash);

    if (!passwordMatch) {
      return response(401, { error: "A senha atual está incorreta." });
    }

    // 4. Gera o hash da nova senha
    const newPasswordHash = await bcrypt.hash(newPassword, 12);

    // 5. Atualiza no DynamoDB
    await dynamo.send(new UpdateCommand({
      TableName: TABLE_NAME,
      Key: {
        PK: `CLINICIAN#${clinicianId}`,
        SK: "PROFILE"
      },
      UpdateExpression: "SET #data.passwordHash = :newHash",
      ExpressionAttributeNames: {
        "#data": "data"
      },
      ExpressionAttributeValues: {
        ":newHash": newPasswordHash
      }
    }));

    return response(200, { message: "Senha alterada com sucesso!" });

  } catch (err) {
    console.error("ERRO_ATUALIZAR_SENHA:", err);
    return response(500, { error: "Erro interno ao atualizar senha." });
  }
};

const response = (statusCode, body) => ({
  statusCode,
  headers: {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*"
  },
  body: JSON.stringify(body)
});