const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, QueryCommand, UpdateCommand } = require("@aws-sdk/lib-dynamodb");
const { SESClient, SendEmailCommand } = require("@aws-sdk/client-ses");
const fs = require("fs");
const path = require("path");

const client = new DynamoDBClient({ region: "sa-east-1" });
const dynamo = DynamoDBDocumentClient.from(client);
const ses    = new SESClient({ region: "sa-east-1" });

const TABLE = "ApsiCare";
const FROM  = "noreply@apsicare.com.br";

exports.handler = async (event) => {
  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return resp(400, { error: "Body inválido" });
  }

  const { email } = body;
  if (!email) return resp(400, { error: "email é obrigatório" });

  try {
    const result = await dynamo.send(new QueryCommand({
      TableName: TABLE,
      IndexName: "GSI1",
      KeyConditionExpression: "GSI1PK = :gsi1pk",
      ExpressionAttributeValues: {
        ":gsi1pk": `EMAIL#${email}`
      }
    }));

    const paciente = (result.Items || []).find(item => item.type === "PATIENT");

    if (!paciente) {
      return resp(200, { message: "Se o e-mail estiver cadastrado, você receberá um código." });
    }

    const codigo    = String(Math.floor(100000 + Math.random() * 900000));
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString();

    await dynamo.send(new UpdateCommand({
      TableName: TABLE,
      Key: { PK: paciente.PK, SK: paciente.SK },
      UpdateExpression: "SET resetCode = :code, resetCodeExpires = :expires",
      ExpressionAttributeValues: {
        ":code":    codigo,
        ":expires": expiresAt
      }
    }));

    // lê o template HTML e substitui as variáveis
    const templatePath = path.join(__dirname, "criarSenha.html");
    let htmlTemplate   = fs.readFileSync(templatePath, "utf-8");

    htmlTemplate = htmlTemplate
      .replace(/\$\{email\}/g,  email)
      .replace(/\$\{codigo\}/g, codigo);

    await ses.send(new SendEmailCommand({
      Source: FROM,
      Destination: { ToAddresses: [email] },
      Message: {
        Subject: { Data: "ApsiCare — Bem-vindo! Crie sua senha de acesso" },
        Body: {
          Html: { Data: htmlTemplate }
        }
      }
    }));

    return resp(200, { message: "Se o e-mail estiver cadastrado, você receberá um código." });

  } catch (err) {
    console.error(err);
    return resp(500, { error: "Erro interno ao processar solicitação" });
  }
};

const resp = (statusCode, body) => ({
  statusCode,
  headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
  body: JSON.stringify(body)
});