import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({ region: "sa-east-1" });
const dynamo = DynamoDBDocumentClient.from(client);
const TABLE_NAME = "PsicoCare";

export const handler = async (event) => {
  try {
    const clinicianId = event.pathParameters?.clinicianId;

    if (!clinicianId) {
      return response(400, { error: "clinicianId é obrigatório" });
    }

    const result = await dynamo.send(new GetCommand({
      TableName: TABLE_NAME,
      Key: {
        PK: `CLINICIAN#${clinicianId}`,
        SK: "PROFILE"
      }
    }));

    if (!result.Item) {
      return response(404, { error: "Psicólogo não encontrado" });
    }

    return response(200, {
      id: clinicianId,
      name: result.Item.data.name,
      email: result.Item.data.email,
      phone: result.Item.data.phone,
      councilId: result.Item.data.councilId,
      profession: result.Item.data.profession,
      birthDate: result.Item.data.birthDate,
      especialidade: result.Item.data.especialidade,
      clinica: result.Item.data.clinica,
      enderecoClinica: result.Item.data.enderecoClinica,
      isActive: result.Item.data.isActive,
      createdAt: result.Item.createdAt,
    });

  } catch (err) {
    console.error(err);
    return response(500, { error: "Erro interno do servidor" });
  }
};

const response = (statusCode, body) => ({
  statusCode,
  headers: {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*"
  },
  body: JSON.stringify(body)
});